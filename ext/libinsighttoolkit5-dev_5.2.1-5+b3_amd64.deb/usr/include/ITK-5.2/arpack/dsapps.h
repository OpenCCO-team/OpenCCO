extern int v3p_netlib_dsapps_(
  v3p_netlib_integer *n,
  v3p_netlib_integer *kev,
  v3p_netlib_integer *np,
  v3p_netlib_doublereal *shift,
  v3p_netlib_doublereal *v,
  v3p_netlib_integer *ldv,
  v3p_netlib_doublereal *h__,
  v3p_netlib_integer *ldh,
  v3p_netlib_doublereal *resid,
  v3p_netlib_doublereal *q,
  v3p_netlib_integer *ldq,
  v3p_netlib_doublereal *workd
  );
