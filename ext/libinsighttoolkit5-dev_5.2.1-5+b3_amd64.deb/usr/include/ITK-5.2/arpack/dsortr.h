extern int v3p_netlib_dsortr_(
  char *which,
  v3p_netlib_logical *apply,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *x1,
  v3p_netlib_doublereal *x2,
  v3p_netlib_ftnlen which_len
  );
