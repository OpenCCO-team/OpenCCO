extern int v3p_netlib_zdscal_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *da,
  v3p_netlib_doublecomplex *zx,
  v3p_netlib_integer *incx
  );
