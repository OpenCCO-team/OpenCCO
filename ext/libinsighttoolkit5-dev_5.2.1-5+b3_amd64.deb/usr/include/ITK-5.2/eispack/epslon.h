extern v3p_netlib_doublereal v3p_netlib_epslon_(
  v3p_netlib_doublereal *x
  );
