extern int v3p_netlib_reduc_(
  v3p_netlib_integer *nm,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *b,
  v3p_netlib_doublereal *dl,
  v3p_netlib_integer *ierr
  );
