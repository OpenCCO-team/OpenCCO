extern v3p_netlib_integer v3p_netlib_izamax_(
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *zx,
  v3p_netlib_integer *incx
  );
