extern int v3p_netlib_drotg_(
  v3p_netlib_doublereal *da,
  v3p_netlib_doublereal *db,
  v3p_netlib_doublereal *c__,
  v3p_netlib_doublereal *s
  );
