extern int v3p_netlib_cdiv_(
  v3p_netlib_doublereal *ar,
  v3p_netlib_doublereal *ai,
  v3p_netlib_doublereal *br,
  v3p_netlib_doublereal *bi,
  v3p_netlib_doublereal *cr,
  v3p_netlib_doublereal *ci
  );
